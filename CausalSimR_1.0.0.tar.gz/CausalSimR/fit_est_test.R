library(ranger)

kl_est <- function(X1, X2,
                               samp.size.max=min(1000, nrow(X1)),
                               mtry=ceiling(sqrt(ncol(X1))),
                               min.node.size=ceiling(log(nrow(X1))),
                               num.trees=100, ratio.trunc.val=100){
  X <- rbind(X1, X2)
  y <- c(rep(0, nrow(X1)), rep(1, nrow(X2)))
  ret <- ranger(y ~., data = cbind.data.frame(y=y, X=X),
                classification=TRUE, probability = TRUE,
                sample.fraction=samp.size.max/nrow(X),
                mtry=mtry, min.node.size = min.node.size, num.trees=num.trees)

  # P(x|0) / P(x|1) = P(0|x) P(1) / P(1|x) P(0)
  ratio <- (ret$predictions[,1] / ret$predictions[,2]) * (nrow(X2)/nrow(X1))
  ratio[ratio > ratio.trunc.val] <- ratio.trunc.val
  ratio[ratio < 1/ratio.trunc.val] <- 1/ratio.trunc.val
  log.ratio <- log(ratio)

  divergence <- max(0.5 * (mean(log.ratio[1:nrow(X1)]) -
                             mean(log.ratio[(nrow(X1)+1):nrow(X)])), 0)
  divergence

}


test.js <- function(N = 1000){
  X1 <- as.data.frame(matrix(runif(N, -1, 1), ncol=10))
  X2 <- as.data.frame(matrix(rnorm(N, 0, 1),  ncol=10))
  X3 <- as.data.frame(matrix(rnorm(N, 0, 1), ncol=10))
  X4 <- as.data.frame(matrix(rnorm(N, 0.5, 1), ncol=10))

  d11 <- kl_est(X1, X1)
  d22 <- kl_est(X2, X2)
  d12 <- kl_est(X1, X2)
  d23 <- kl_est(X2, X3)
  d24 <- kl_est(X2, X4)

  print(sprintf("d11 = %5.2f \n
        d22 = %5.2f \n,
        d12 = %5.2f \n
        d23 = %5.2f \n
        d24 = %5.2f \n",        d11, d22, d12, d23, d24))

}
