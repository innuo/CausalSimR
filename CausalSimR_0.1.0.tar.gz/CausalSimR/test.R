library(GGally)
library(CausalSimR)
test_sampler = function(full.data = iris, train.sample.size, samples.to.draw, plots=FALSE){

  data <- full.data[sample(1:nrow(full.data), train.sample.size),]
  dataset <- DataSet$new(data)
  sim <- CausalSimModel$new(dataset)
  sim$learn()
  sampled.data <- sim$sample(samples.to.draw)

  browser()
  sim$plot()
  ggpairs(full.data, title=sprintf("Full Data: %d samples",nrow(full.data)))
  ggpairs(data, title=sprintf("Train Data: %d samples",nrow(data)))
  ggpairs(sampled.data, title=sprintf("Sim Data: %d samples",nrow(sampled.data)))
  sampled.data
}

